A Pen created at CodePen.io. You can find this one at https://codepen.io/MatthewShields/pen/XgeRWj.

 Simple shape styles for radio and checkbox buttons